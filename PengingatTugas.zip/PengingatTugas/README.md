# Pengingat Tugas (Android Studio, Kotlin) — Tema Pink

Aplikasi pengingat tugas dengan tema pink. Daftar tugas disimpan di **SQLite**,
pengaturan pengguna disimpan di **SharedPreferences** lewat kelas **PrefsManager**.

## Cara Membuka
1. Ekstrak ZIP, lalu di Android Studio pilih **File > Open** dan pilih folder `PengingatTugas`.
2. Tunggu **Gradle Sync** selesai (butuh internet; Android Studio akan mengunduh Gradle 8.7 otomatis).
3. Jalankan di emulator / HP (Android 8.0+ / API 26+).
   Jika diminta JDK, pakai JDK 17 (bawaan Android Studio Jellyfish/Koala).

## Fitur
- Tambah tugas (judul, catatan, tanggal & jam tenggat), centang selesai, hapus.
- Notifikasi pengingat sebelum tenggat (AlarmManager), dijadwalkan ulang setelah HP restart.
- Pengaturan: nama, notifikasi, mode gelap, tampilkan tugas selesai, urutan, waktu pengingat.
- Layar **Keterangan** (ikon i di toolbar) berisi 5 poin + data SharedPreferences live.

---

## KETERANGAN

### 1. Masalah yang Diselesaikan Aplikasi
Pelajar dan pekerja sering lupa tenggat karena catatan tersebar dan tanpa peringatan.
Aplikasi menyimpan daftar tugas beserta tenggat, lalu mengirim notifikasi sebelum waktu habis.
Preferensi pengguna (nama, tema, urutan, waktu pengingat) tidak perlu diatur ulang setiap aplikasi dibuka.

### 2. Data di SharedPreferences + Alasan
| Key | Isi | 
|---|---|
| `user_name` | Nama untuk sapaan |
| `notif_enabled` | Notifikasi aktif/mati |
| `dark_mode` | Tema gelap/terang |
| `show_completed` | Tampilkan tugas selesai |
| `sort_by` | Urutan: tenggat / judul |
| `reminder_minutes` | 10 / 30 / 60 menit sebelum tenggat |
| `launch_count` | Berapa kali aplikasi dibuka (bukti) |
| `last_opened` | Waktu terakhir dibuka (bukti) |

**Alasan:** datanya kecil, sederhana (key-value), dan berupa pengaturan yang harus langsung tersedia
saat aplikasi mulai (misalnya mode gelap diterapkan di `App.onCreate()` sebelum layar tampil).
SharedPreferences cepat dan tidak butuh query atau skema tabel.

### 3. Data di Database / Tidak Disimpan + Alasan
**Database SQLite (`tugas.db`, tabel `tasks`):** judul, catatan, tenggat, status selesai.
Alasannya jumlahnya bisa banyak, terstruktur seperti tabel, dan perlu diurutkan, difilter, diubah, serta dihapus per baris.

**Tidak disimpan:** teks yang sedang diketik di form sebelum menekan Simpan, dan posisi scroll daftar.
Alasannya bersifat sementara dan tidak berguna setelah layar ditutup, sehingga menyimpannya hanya memboroskan ruang.

### 4. Cara Kerja: PrefsManager, apply(), dibaca di onResume()
```kotlin
class PrefsManager(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("pengaturan_pengingat", Context.MODE_PRIVATE)

    var userName: String
        get() = prefs.getString("user_name", "") ?: ""
        set(value) = prefs.edit().putString("user_name", value).apply()   // <- apply()
}
```
- **PrefsManager** adalah satu-satunya pintu akses SharedPreferences; Activity tidak menyentuh `getSharedPreferences` langsung.
- **apply()** memperbarui memori seketika lalu menulis file XML di thread latar, sehingga UI tidak tersendat.
  (`commit()` bersifat sinkron dan mengembalikan Boolean; di sini tidak dibutuhkan.)
- **onResume()**: `MainActivity` membaca nama, urutan, dan filter dari PrefsManager setiap layar tampil kembali,
  dan `SettingsActivity` membaca nilai tersimpan ke saklar dan radio. Jadi tampilan selalu sama dengan data tersimpan,
  termasuk setelah kembali dari layar Pengaturan.

Alur: `Pengaturan -> tombol Simpan -> PrefsManager.setter (apply) -> file shared_prefs/pengaturan_pengingat.xml -> onResume() -> getter -> tampilan`

### 5. Bukti: Setelah Force Stop Pengaturan Tetap Ada
1. Buka **Pengaturan**, isi nama (mis. "Putri"), aktifkan **Mode gelap**, pilih urutan **Judul**, tekan **Simpan Pengaturan**.
2. Catat angka **"Dibuka Nx"** di kartu pink halaman utama.
3. HP: *Pengaturan > Aplikasi > Pengingat Tugas > Paksa Berhenti* (Force Stop).
   Atau via terminal: `adb shell am force-stop com.pengingat.tugas`.
4. Buka aplikasi lagi.

**Hasil yang terlihat:** sapaan tetap "Halo, Putri!", tema tetap gelap, urutan tetap Judul, dan penghitung
menjadi N+1 (tidak kembali ke 1). Semua itu karena SharedPreferences ditulis ke file XML di penyimpanan internal,
bukan hanya di memori proses. Layar **Keterangan** menampilkan nilai-nilai ini langsung dari file tersebut.

Verifikasi file (emulator / perangkat debug):
```
adb shell run-as com.pengingat.tugas cat shared_prefs/pengaturan_pengingat.xml
```

## Struktur Kode
```
app/src/main/java/com/pengingat/tugas/
  App.kt                 -> channel notifikasi + terapkan mode gelap dari prefs
  PrefsManager.kt        -> pembungkus SharedPreferences (apply)
  TaskDbHelper.kt        -> SQLite untuk daftar tugas
  Task.kt                -> model data
  MainActivity.kt        -> daftar tugas, baca prefs di onResume()
  AddTaskActivity.kt     -> form tambah tugas
  SettingsActivity.kt    -> simpan / baca pengaturan
  InfoActivity.kt        -> keterangan + data prefs live
  ReminderScheduler.kt / ReminderReceiver.kt / BootReceiver.kt -> alarm & notifikasi
  TaskAdapter.kt         -> RecyclerView adapter
```

## Palet Warna Pink
`#E91E63` utama, `#C2185B` gelap, `#880E4F` teks gelap, `#F8BBD0` muda, `#FF4081` aksen, `#FFF0F5` latar.

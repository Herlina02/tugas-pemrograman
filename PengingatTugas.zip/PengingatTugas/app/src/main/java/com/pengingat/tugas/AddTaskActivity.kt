package com.pengingat.tugas

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AddTaskActivity : AppCompatActivity() {

    private val cal: Calendar = Calendar.getInstance().apply { add(Calendar.HOUR_OF_DAY, 1) }
    private val fmt = SimpleDateFormat("EEEE, dd MMMM yyyy  HH:mm", Locale("id", "ID"))
    private lateinit var tvDeadline: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_task)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Tambah Tugas"

        val etTitle = findViewById<TextInputEditText>(R.id.etTitle)
        val etNote = findViewById<TextInputEditText>(R.id.etNote)
        tvDeadline = findViewById(R.id.tvDeadline)
        showDeadline()

        findViewById<Button>(R.id.btnDate).setOnClickListener {
            DatePickerDialog(this, { _, y, m, d ->
                cal.set(y, m, d)
                showDeadline()
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        findViewById<Button>(R.id.btnTime).setOnClickListener {
            TimePickerDialog(this, { _, h, min ->
                cal.set(Calendar.HOUR_OF_DAY, h)
                cal.set(Calendar.MINUTE, min)
                cal.set(Calendar.SECOND, 0)
                showDeadline()
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val judul = etTitle.text.toString().trim()
            if (judul.isEmpty()) {
                etTitle.error = "Judul tugas wajib diisi"
                return@setOnClickListener
            }
            val task = Task(
                title = judul,
                note = etNote.text.toString().trim(),
                deadline = cal.timeInMillis
            )
            val id = TaskDbHelper(this).insert(task)
            ReminderScheduler.schedule(this, task.copy(id = id))
            Toast.makeText(this, "Tugas disimpan", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun showDeadline() {
        tvDeadline.text = fmt.format(cal.time)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { finish(); return true }
        return super.onOptionsItemSelected(item)
    }
}

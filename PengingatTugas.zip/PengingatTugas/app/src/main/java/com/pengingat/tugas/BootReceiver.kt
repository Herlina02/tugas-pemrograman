package com.pengingat.tugas

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Alarm hilang saat HP restart, jadi dijadwalkan ulang dari database. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            TaskDbHelper(context).getAll()
                .filter { !it.done }
                .forEach { ReminderScheduler.schedule(context, it) }
        }
    }
}

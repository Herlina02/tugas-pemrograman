package com.pengingat.tugas

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

/** Mengatur alarm pengingat. Waktu pengingat = tenggat - reminderMinutes (dari SharedPreferences). */
object ReminderScheduler {

    fun schedule(context: Context, task: Task) {
        if (task.done) return
        val minutes = PrefsManager(context).reminderMinutes
        val triggerAt = task.deadline - minutes * 60_000L
        if (triggerAt <= System.currentTimeMillis()) return

        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            triggerAt,
            pendingIntent(context, task.id, task.title, task.deadline)
        )
    }

    fun cancel(context: Context, taskId: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context, taskId, "", 0L))
    }

    private fun pendingIntent(context: Context, id: Long, title: String, deadline: Long): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(ReminderReceiver.EXTRA_ID, id)
            putExtra(ReminderReceiver.EXTRA_TITLE, title)
            putExtra(ReminderReceiver.EXTRA_DEADLINE, deadline)
        }
        return PendingIntent.getBroadcast(
            context, id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}

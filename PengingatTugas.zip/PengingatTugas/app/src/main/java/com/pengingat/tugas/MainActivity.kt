package com.pengingat.tugas

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager
    private lateinit var db: TaskDbHelper
    private lateinit var adapter: TaskAdapter
    private lateinit var tvGreeting: TextView
    private lateinit var tvStats: TextView
    private lateinit var tvEmpty: TextView

    private var previousOpen: Long = 0L

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))

        prefs = PrefsManager(this)
        db = TaskDbHelper(this)

        tvGreeting = findViewById(R.id.tvGreeting)
        tvStats = findViewById(R.id.tvStats)
        tvEmpty = findViewById(R.id.tvEmpty)

        adapter = TaskAdapter(
            onToggle = { task, done ->
                db.setDone(task.id, done)
                if (done) ReminderScheduler.cancel(this, task.id)
                else ReminderScheduler.schedule(this, task.copy(done = false))
                refreshList()
            },
            onDelete = { task ->
                ReminderScheduler.cancel(this, task.id)
                db.delete(task.id)
                refreshList()
            }
        )
        findViewById<RecyclerView>(R.id.rvTasks).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<FloatingActionButton>(R.id.fabAdd).setOnClickListener {
            startActivity(Intent(this, AddTaskActivity::class.java))
        }

        // BUKTI penyimpanan: catat jumlah buka & waktu terakhir ke SharedPreferences
        previousOpen = prefs.lastOpened
        prefs.launchCount = prefs.launchCount + 1
        prefs.lastOpened = System.currentTimeMillis()

        askNotificationPermission()
    }

    /** Setiap layar kembali tampil, pengaturan dibaca ulang dari SharedPreferences. */
    override fun onResume() {
        super.onResume()
        val name = prefs.userName
        tvGreeting.text = if (name.isBlank()) "Halo! Yuk kelola tugasmu" else "Halo, $name!"

        val fmt = SimpleDateFormat("dd MMM yyyy HH:mm", Locale("id", "ID"))
        val terakhir = if (previousOpen == 0L) "pertama kali" else fmt.format(Date(previousOpen))
        tvStats.text = "Dibuka ${prefs.launchCount}x  |  Terakhir dibuka: $terakhir"

        refreshList()
    }

    private fun refreshList() {
        var list = db.getAll()
        if (!prefs.showCompleted) list = list.filter { !it.done }
        list = if (prefs.sortBy == PrefsManager.SORT_TITLE)
            list.sortedBy { it.title.lowercase() }
        else
            list.sortedWith(compareBy<Task> { it.done }.thenBy { it.deadline })

        adapter.submit(list)
        tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_settings -> { startActivity(Intent(this, SettingsActivity::class.java)); true }
        R.id.action_info -> { startActivity(Intent(this, InfoActivity::class.java)); true }
        else -> super.onOptionsItemSelected(item)
    }
}

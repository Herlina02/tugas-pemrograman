package com.pengingat.tugas

/** Model satu tugas. Disimpan di database SQLite (bukan SharedPreferences). */
data class Task(
    val id: Long = 0,
    val title: String,
    val note: String,
    val deadline: Long,      // waktu tenggat dalam milidetik
    val done: Boolean = false
)

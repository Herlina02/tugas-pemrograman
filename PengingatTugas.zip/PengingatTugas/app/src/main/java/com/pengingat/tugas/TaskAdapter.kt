package com.pengingat.tugas

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Locale

class TaskAdapter(
    private val onToggle: (Task, Boolean) -> Unit,
    private val onDelete: (Task) -> Unit
) : RecyclerView.Adapter<TaskAdapter.VH>() {

    private var items: List<Task> = emptyList()
    private val fmt = SimpleDateFormat("EEE, dd MMM yyyy HH:mm", Locale("id", "ID"))

    fun submit(list: List<Task>) {
        items = list
        notifyDataSetChanged()
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val check: CheckBox = v.findViewById(R.id.cbDone)
        val title: TextView = v.findViewById(R.id.tvTitle)
        val note: TextView = v.findViewById(R.id.tvNote)
        val deadline: TextView = v.findViewById(R.id.tvDeadline)
        val delete: ImageButton = v.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_task, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val t = items[position]
        h.title.text = t.title
        h.note.text = t.note
        h.note.visibility = if (t.note.isBlank()) View.GONE else View.VISIBLE
        h.deadline.text = "Tenggat: " + fmt.format(t.deadline)

        val overdue = !t.done && t.deadline < System.currentTimeMillis()
        h.deadline.setTextColor(if (overdue) 0xFFD32F2F.toInt() else 0xFFC2185B.toInt())

        h.title.paintFlags = if (t.done)
            h.title.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        else
            h.title.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()

        h.check.setOnCheckedChangeListener(null)
        h.check.isChecked = t.done
        h.check.setOnCheckedChangeListener { _, checked -> onToggle(t, checked) }
        h.delete.setOnClickListener { onDelete(t) }
    }
}

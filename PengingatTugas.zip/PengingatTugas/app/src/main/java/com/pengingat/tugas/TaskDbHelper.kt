package com.pengingat.tugas

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Database SQLite untuk daftar tugas (data berjumlah banyak & terstruktur). */
class TaskDbHelper(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DB_NAME, null, DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE $TABLE (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_TITLE TEXT NOT NULL,
                $COL_NOTE TEXT,
                $COL_DEADLINE INTEGER NOT NULL,
                $COL_DONE INTEGER NOT NULL DEFAULT 0
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE")
        onCreate(db)
    }

    fun insert(task: Task): Long {
        val cv = ContentValues().apply {
            put(COL_TITLE, task.title)
            put(COL_NOTE, task.note)
            put(COL_DEADLINE, task.deadline)
            put(COL_DONE, if (task.done) 1 else 0)
        }
        return writableDatabase.insert(TABLE, null, cv)
    }

    fun setDone(id: Long, done: Boolean) {
        val cv = ContentValues().apply { put(COL_DONE, if (done) 1 else 0) }
        writableDatabase.update(TABLE, cv, "$COL_ID = ?", arrayOf(id.toString()))
    }

    fun delete(id: Long) {
        writableDatabase.delete(TABLE, "$COL_ID = ?", arrayOf(id.toString()))
    }

    fun getAll(): List<Task> {
        val list = mutableListOf<Task>()
        readableDatabase.query(TABLE, null, null, null, null, null, "$COL_DEADLINE ASC").use { c ->
            while (c.moveToNext()) {
                list.add(
                    Task(
                        id = c.getLong(c.getColumnIndexOrThrow(COL_ID)),
                        title = c.getString(c.getColumnIndexOrThrow(COL_TITLE)),
                        note = c.getString(c.getColumnIndexOrThrow(COL_NOTE)) ?: "",
                        deadline = c.getLong(c.getColumnIndexOrThrow(COL_DEADLINE)),
                        done = c.getInt(c.getColumnIndexOrThrow(COL_DONE)) == 1
                    )
                )
            }
        }
        return list
    }

    companion object {
        private const val DB_NAME = "tugas.db"
        private const val DB_VERSION = 1
        private const val TABLE = "tasks"
        private const val COL_ID = "id"
        private const val COL_TITLE = "title"
        private const val COL_NOTE = "note"
        private const val COL_DEADLINE = "deadline"
        private const val COL_DONE = "done"
    }
}

package com.pengingat.tugas

import android.os.Bundle
import android.view.MenuItem
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Layar Keterangan: menjelaskan 5 poin + menampilkan data langsung dari SharedPreferences sebagai bukti. */
class InfoActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager
    private lateinit var tvLive: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_info)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Keterangan Aplikasi"

        prefs = PrefsManager(this)
        tvLive = findViewById(R.id.tvLive)
    }

    override fun onResume() {
        super.onResume()
        val fmt = SimpleDateFormat("dd MMM yyyy HH:mm:ss", Locale("id", "ID"))
        val urut = if (prefs.sortBy == PrefsManager.SORT_TITLE) "Judul" else "Tenggat"
        tvLive.text = """
            Nama pengguna     : ${prefs.userName.ifBlank { "(belum diisi)" }}
            Notifikasi        : ${if (prefs.notificationsEnabled) "Aktif" else "Mati"}
            Mode gelap        : ${if (prefs.darkMode) "Aktif" else "Mati"}
            Tampilkan selesai : ${if (prefs.showCompleted) "Ya" else "Tidak"}
            Urutan tugas      : $urut
            Pengingat         : ${prefs.reminderMinutes} menit sebelum tenggat
            Jumlah dibuka     : ${prefs.launchCount} kali
            Terakhir dibuka   : ${if (prefs.lastOpened == 0L) "-" else fmt.format(Date(prefs.lastOpened))}
        """.trimIndent()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { finish(); return true }
        return super.onOptionsItemSelected(item)
    }
}

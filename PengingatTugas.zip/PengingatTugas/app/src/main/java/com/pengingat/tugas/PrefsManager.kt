package com.pengingat.tugas

import android.content.Context
import android.content.SharedPreferences

/**
 * PrefsManager = satu-satunya pintu untuk membaca/menulis SharedPreferences.
 *
 * - Setiap setter memakai apply() -> menulis ke memori langsung, lalu disimpan
 *   ke file XML (shared_prefs/pengaturan_pengingat.xml) secara asinkron.
 * - Activity membaca nilainya lagi di onResume() supaya tampilan selalu sinkron.
 */
class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    var userName: String
        get() = prefs.getString(KEY_USER_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_USER_NAME, value).apply()

    var notificationsEnabled: Boolean
        get() = prefs.getBoolean(KEY_NOTIF, true)
        set(value) = prefs.edit().putBoolean(KEY_NOTIF, value).apply()

    var darkMode: Boolean
        get() = prefs.getBoolean(KEY_DARK, false)
        set(value) = prefs.edit().putBoolean(KEY_DARK, value).apply()

    var showCompleted: Boolean
        get() = prefs.getBoolean(KEY_SHOW_DONE, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_DONE, value).apply()

    /** 0 = urut berdasarkan tenggat, 1 = urut berdasarkan judul */
    var sortBy: Int
        get() = prefs.getInt(KEY_SORT, SORT_DEADLINE)
        set(value) = prefs.edit().putInt(KEY_SORT, value).apply()

    /** Berapa menit sebelum tenggat pengingat dibunyikan */
    var reminderMinutes: Int
        get() = prefs.getInt(KEY_REMINDER_MIN, 30)
        set(value) = prefs.edit().putInt(KEY_REMINDER_MIN, value).apply()

    /** Dipakai sebagai BUKTI: jumlah aplikasi dibuka, bertahan walau force stop */
    var launchCount: Int
        get() = prefs.getInt(KEY_LAUNCH_COUNT, 0)
        set(value) = prefs.edit().putInt(KEY_LAUNCH_COUNT, value).apply()

    /** Dipakai sebagai BUKTI: waktu terakhir aplikasi dibuka */
    var lastOpened: Long
        get() = prefs.getLong(KEY_LAST_OPENED, 0L)
        set(value) = prefs.edit().putLong(KEY_LAST_OPENED, value).apply()

    companion object {
        const val PREF_NAME = "pengaturan_pengingat"
        const val SORT_DEADLINE = 0
        const val SORT_TITLE = 1

        private const val KEY_USER_NAME = "user_name"
        private const val KEY_NOTIF = "notif_enabled"
        private const val KEY_DARK = "dark_mode"
        private const val KEY_SHOW_DONE = "show_completed"
        private const val KEY_SORT = "sort_by"
        private const val KEY_REMINDER_MIN = "reminder_minutes"
        private const val KEY_LAUNCH_COUNT = "launch_count"
        private const val KEY_LAST_OPENED = "last_opened"
    }
}

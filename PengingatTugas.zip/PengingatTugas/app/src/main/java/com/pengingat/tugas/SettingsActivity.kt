
package com.pengingat.tugas

import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SwitchCompat
import androidx.appcompat.widget.Toolbar

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Pengaturan"

        prefs = PrefsManager(this)

        val etName = findViewById<EditText>(R.id.etName)
        val swNotif = findViewById<SwitchCompat>(R.id.swNotif)
        val swDark = findViewById<SwitchCompat>(R.id.swDark)
        val swShowDone = findViewById<SwitchCompat>(R.id.swShowDone)
        val rgSort = findViewById<RadioGroup>(R.id.rgSort)
        val rgReminder = findViewById<RadioGroup>(R.id.rgReminder)

        // Memuat pengaturan
        etName.setText(prefs.userName)
        swNotif.isChecked = prefs.notificationsEnabled
        swDark.isChecked = prefs.darkMode
        swShowDone.isChecked = prefs.showCompleted

        rgSort.check(
            if (prefs.sortBy == PrefsManager.SORT_TITLE)
                R.id.rbSortTitle
            else
                R.id.rbSortDeadline
        )

        rgReminder.check(
            when (prefs.reminderMinutes) {
                10 -> R.id.rbMin10
                60 -> R.id.rbMin60
                else -> R.id.rbMin30
            }
        )

        // Tombol simpan
        findViewById<Button>(R.id.btnSaveSettings)
            .setOnClickListener {

                prefs.userName = etName.text.toString().trim()
                prefs.notificationsEnabled = swNotif.isChecked
                prefs.showCompleted = swShowDone.isChecked

                prefs.sortBy =
                    if (rgSort.checkedRadioButtonId == R.id.rbSortTitle)
                        PrefsManager.SORT_TITLE
                    else
                        PrefsManager.SORT_DEADLINE

                prefs.reminderMinutes =
                    when (rgReminder.checkedRadioButtonId) {
                        R.id.rbMin10 -> 10
                        R.id.rbMin60 -> 60
                        else -> 30
                    }

                val darkChanged = prefs.darkMode != swDark.isChecked
                prefs.darkMode = swDark.isChecked

                Toast.makeText(
                    this,
                    "Pengaturan berhasil disimpan",
                    Toast.LENGTH_SHORT
                ).show()

                if (darkChanged) {
                    AppCompatDelegate.setDefaultNightMode(
                        if (swDark.isChecked)
                            AppCompatDelegate.MODE_NIGHT_YES
                        else
                            AppCompatDelegate.MODE_NIGHT_NO
                    )
                }
            }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}

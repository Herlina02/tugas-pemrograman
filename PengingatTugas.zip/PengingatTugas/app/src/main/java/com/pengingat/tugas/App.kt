package com.pengingat.tugas

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.appcompat.app.AppCompatDelegate

class App : Application() {
    override fun onCreate() {
        super.onCreate()

        // Terapkan tema gelap/terang dari SharedPreferences setiap proses dimulai.
        // Inilah yang membuktikan pengaturan tetap ada setelah force stop.
        val dark = PrefsManager(this).darkMode
        AppCompatDelegate.setDefaultNightMode(
            if (dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )

        val channel = NotificationChannel(
            CHANNEL_ID, "Pengingat Tugas", NotificationManager.IMPORTANCE_HIGH
        ).apply { description = "Notifikasi pengingat tenggat tugas" }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    companion object {
        const val CHANNEL_ID = "pengingat_tugas"
    }
}
